import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

const PORT = 6886;
const CONFIG_FILE = path.resolve(process.env.HOME || process.env.USERPROFILE, '.syncpilot_config.json');

const DEFAULT_PROMPT = `【代码交付规范】
请严格遵守以下格式输出所有代码，以便我的自动化脚本直接批量写入本地工程：
1. 每一个独立代码块的首行必须严格声明文件相对路径，格式为：// filepath: 你的相对路径
2. 代码块内只包含该文件完整内容，不要添加额外的非代码说明文字在代码块内部。
3. 允许多个文件同时在一次回答中输出。`;

let config = {
  currentProject: process.cwd(),
  backupEnabled: true,
  customPrompt: DEFAULT_PROMPT,
  history: []
};

if (fs.existsSync(CONFIG_FILE)) {
  try { config = { ...config, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8')) }; } catch {}
}

function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

function handleWriteFile(filepath, code) {
  const fullPath = path.resolve(config.currentProject, filepath);
  
  if (config.backupEnabled && fs.existsSync(fullPath)) {
    const backupDir = path.resolve(config.currentProject, '.sync_backup', path.dirname(filepath));
    fs.mkdirSync(backupDir, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    fs.copyFileSync(fullPath, path.join(backupDir, `${path.basename(filepath)}.${timestamp}.bak`));
  }

  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, code, 'utf-8');

  config.history.unshift({
    time: new Date().toLocaleTimeString(),
    file: filepath,
    size: code.length
  });
  if (config.history.length > 20) config.history.pop();
  saveConfig();
}

// ---------------- 零开销长驻剪贴板监听器 ----------------
let psProcess = null;
let lastContent = '';

function startClipboardWatcher() {
  if (process.platform !== 'win32') return;

  // 启动单个长驻 PowerShell 会话，不在循环中重复启动进程
  const psScript = `
    Add-Type -AssemblyName System.Windows.Forms
    $last = ""
    while($true) {
      Start-Sleep -Milliseconds 800
      if ([System.Windows.Forms.Clipboard]::ContainsText()) {
        $text = [System.Windows.Forms.Clipboard]::GetText()
        if ($text -ne $last) {
          $last = $text
          $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
          $b64 = [Convert]::ToBase64String($bytes)
          [Console]::WriteLine("---CLIP_START---" + $b64 + "---CLIP_END---")
        }
      }
    }
  `;

  psProcess = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript], {
    stdio: ['ignore', 'pipe', 'ignore']
  });

  let buffer = '';
  psProcess.stdout.on('data', (chunk) => {
    buffer += chunk.toString();
    while (buffer.includes('---CLIP_START---') && buffer.includes('---CLIP_END---')) {
      const start = buffer.indexOf('---CLIP_START---') + 16;
      const end = buffer.indexOf('---CLIP_END---');
      const b64 = buffer.slice(start, end).trim();
      buffer = buffer.slice(end + 14);

      try {
        const text = Buffer.from(b64, 'base64').toString('utf-8');
        processClipboardText(text);
      } catch {}
    }
  });

  psProcess.on('exit', () => {
    // 意外退出时自动平滑重启
    setTimeout(startClipboardWatcher, 2000);
  });
}

function processClipboardText(content) {
  if (!content || content === lastContent) return;
  lastContent = content;

  // 批量匹配
  const fileRegex = /```[^\n\r]*[\r\n]+\/\/\s*filepath:\s*([^\n\r]+)[\r\n]+([\s\S]*?)```/gi;
  let match;
  let matchCount = 0;

  while ((match = fileRegex.exec(content)) !== null) {
    matchCount++;
    handleWriteFile(match[1].trim(), match[2]);
    console.log(`\x1b[32m[批量同步 (${matchCount})]\x1b[0m ${match[1].trim()}`);
  }

  // 单文件无代码块匹配
  if (matchCount === 0) {
    const singleMatch = content.match(/^\/\/\s*filepath:\s*([^\n\r]+)[\r\n]+([\s\S]*)/i);
    if (singleMatch) {
      handleWriteFile(singleMatch[1].trim(), singleMatch[2]);
      console.log(`\x1b[32m[单文件同步]\x1b[0m ${singleMatch[1].trim()}`);
    }
  }
}

// 启动常驻监听
startClipboardWatcher();

// ---------------- Web 控制面板服务 ----------------
const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.url === '/api/set-config' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { projectPath, backup, customPrompt } = JSON.parse(body);
      if (projectPath && fs.existsSync(projectPath)) {
        config.currentProject = projectPath;
        if (backup !== undefined) config.backupEnabled = backup;
        if (customPrompt !== undefined) config.customPrompt = customPrompt;
        saveConfig();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, config }));
      } else {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: '项目路径不存在' }));
      }
    });
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>SyncPilot 控制面板</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f1f5f9; margin: 0; padding: 32px 16px; }
        .container { max-width: 720px; margin: 0 auto; }
        .card { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
        h1 { margin-top: 0; font-size: 20px; color: #38bdf8; display: flex; justify-content: space-between; align-items: center; }
        label { display: block; font-size: 13px; font-weight: 600; color: #94a3b8; margin-top: 14px; margin-bottom: 6px; }
        input[type="text"], textarea { width: 100%; box-sizing: border-box; padding: 10px 12px; background: #0f172a; border: 1px solid #334155; border-radius: 6px; color: #f8fafc; font-size: 13px; font-family: inherit; }
        textarea { height: 110px; line-height: 1.45; resize: vertical; }
        .btn-row { display: flex; gap: 10px; margin-top: 14px; align-items: center; }
        button { background: #2563eb; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; transition: background 0.2s; }
        button:hover { background: #1d4ed8; }
        button.secondary { background: #334155; }
        button.secondary:hover { background: #475569; }
        button.copy-btn { background: #10b981; }
        button.copy-btn:hover { background: #059669; }
        .badge { font-size: 12px; color: #4ade80; background: #064e3b; padding: 3px 8px; border-radius: 12px; font-weight: normal; }
        .history { max-height: 180px; overflow-y: auto; }
        .item { font-size: 12px; padding: 8px 0; display: flex; justify-content: space-between; border-bottom: 1px solid #334155; }
        .copy-toast { display: inline-block; margin-left: 10px; font-size: 12px; color: #34d399; opacity: 0; transition: opacity 0.3s; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="card">
          <h1>SyncPilot 控制中心 <span class="badge">● 极低功耗模式已激活</span></h1>
          <label>当前生效的本地项目根路径：</label>
          <input type="text" id="proj" value="${config.currentProject}" />
          <div class="btn-row">
            <button onclick="saveSettings()">保存配置与路径</button>
            <label style="margin: 0; display: flex; align-items: center; cursor: pointer; font-size: 13px; color: #cbd5e1;">
              <input type="checkbox" id="backup" ${config.backupEnabled ? 'checked' : ''} style="margin-right: 6px;" /> 覆写前在 .sync_backup 自动备份
            </label>
          </div>
        </div>

        <div class="card">
          <h2 style="font-size: 16px; margin: 0 0 8px 0; color: #fbbf24;">🤖 AI 标准化交互指令 (Prompt)</h2>
          <p style="font-size: 12px; color: #94a3b8; margin: 0 0 10px 0;">在新会话或切换新项目时，将此指令发送给 AI：</p>
          <textarea id="promptArea">${config.customPrompt}</textarea>
          <div class="btn-row">
            <button class="copy-btn" onclick="copyPrompt()">📋 一键复制提示词</button>
            <button class="secondary" onclick="saveSettings()">保存修改后的提示词</button>
            <span id="toast" class="copy-toast">✓ 已成功复制到剪贴板！</span>
          </div>
        </div>

        <div class="card">
          <h2 style="font-size: 15px; margin: 0 0 10px 0; color: #94a3b8;">最近文件同步记录</h2>
          <div class="history">
            ${config.history.map(h => `<div class="item"><span>📄 ${h.file}</span><span style="color: #64748b;">${h.time} (${h.size} 字节)</span></div>`).join('') || '<div style="color: #64748b; font-size: 12px;">暂无写入历史</div>'}
          </div>
        </div>
      </div>

      <script>
        function saveSettings() {
          const payload = {
            projectPath: document.getElementById('proj').value,
            backup: document.getElementById('backup').checked,
            customPrompt: document.getElementById('promptArea').value
          };
          fetch('/api/set-config', {
            method: 'POST',
            body: JSON.stringify(payload)
          }).then(r => r.json()).then(d => {
            if (d.success) alert('设置已更新并持久化！');
            else alert(d.error);
          });
        }

        function copyPrompt() {
          const text = document.getElementById('promptArea').value;
          navigator.clipboard.writeText(text).then(() => {
            const toast = document.getElementById('toast');
            toast.style.opacity = '1';
            setTimeout(() => toast.style.opacity = '0', 2000);
          });
        }
      </script>
    </body>
    </html>
  `);
});

server.listen(PORT, () => {
  console.log(`\x1b[36m🚀 SyncPilot (极低功耗模式) 已启动: http://localhost:${PORT}\x1b[0m`);
});