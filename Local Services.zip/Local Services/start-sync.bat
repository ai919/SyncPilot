// filepath: start-sync.bat
@echo off
chcp 65001 >nul
title SyncPilot 代码同步服务

echo ===================================================
echo   🚀 正在启动 SyncPilot 代码自动同步后台服务...
echo ===================================================

:: 自动延迟 1.5 秒后在默认浏览器中打开控制面板
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:6886"

:: 启动核心 Node 守护脚本
node "%~dp0sync-daemon.js"

pause